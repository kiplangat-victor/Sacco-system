package co.ke.emtechhouse.Utils;

public class CONSTANTS {
    public static final Character YES = 'Y';
    public static final Character NO = 'N';
    public static final Character ODA = 'O';
    public static final Character PERCENTAGE = 'P';
    public static final Character FIXED_AMOUNT = 'F';
    public static final Character AMOUNT_SLABS = 'S';
}
